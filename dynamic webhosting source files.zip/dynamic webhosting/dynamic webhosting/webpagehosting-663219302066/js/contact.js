$(document).ready(function() {
    // Get value on button click and show alert
    $("#myBtn").click(function() {
        var name = $("#name").val();
        console.log(name);
        var email = $("#email").val();
        console.log(email);
        var subject = $("#subject").val();
        console.log(subject);
        var message = $('textarea#message').val();
        console.log(message);
        if (name == "") {
            $("#datamsg").text("Enter your name");
            $("#datamsg").show();
        } else if (email == "") {
            $("#datamsg").text("Enter your email");
            $("#datamsg").show();
        } else if (subject == "") {
            $("#datamsg").text("Enter your Subject");
            $("#datamsg").show();
        } else if (message == "") {
            $("#datamsg").text("Enter your message");
            $("#datamsg").show();
        } else {
            var myurl = "https://op2kzznfje.execute-api.us-east-1.amazonaws.com/v1/contact";
            var mydata = {
                "name": name,
                "email": email,
                "subject": subject,
                "message": message
            }
            $.ajax({
                url: myurl,
                data: JSON.stringify(mydata),
                headers: {
                    "content-type": "application/json"
                },
                method: "POST",
                success: function(data) {
                    $("#datamsg").text('We will get in touch with you very soon');
                    $("#datamsg").show();
                    $("form")[0].reset();
                }
            })
        }
    })
})